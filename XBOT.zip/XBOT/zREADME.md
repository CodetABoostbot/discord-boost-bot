FOR HOSTING

PUT THIS ON "ADDITIONAL PYTHON PACKAGES"

discord.py discord.py[voice] py-cord==2.1.3 py-cord[voice]

and start. DONE!